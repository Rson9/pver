package main

import "github.com/rson9/pver/cmd"

func main() {
	cmd.Execute()
}
